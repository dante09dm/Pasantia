<template>
<v-dialog>
  
</v-dialog>
  <v-card>
    <v-card-title>
      <span class="text-h5">{{title}}</span>
    </v-card-title>
    <v-card-text>
      <FormEditPhone titulo="titulo"/>
    </v-card-text>
  </v-card>
</template>

<script>
import FormEditPhone from '@/components/forms/FormEditPhone.vue';
  export default {
    data: () => ({
        dialog: false,
    }),
    components: { 
      FormEditPhone 
    },
    props: ['titulo'],
  }


</script>