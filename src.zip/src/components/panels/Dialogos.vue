<template>
  <v-card>
    <v-card-title>
      <span class="text-h5">{{ titulo }}</span>
    </v-card-title>
    <v-card-text>
      <v-container>
 
      </v-container>
    </v-card-text>
    <v-card-actions>

    </v-card-actions>
  </v-card>
</template>
<script>
export default {

  data() {
    return {
      dialog: false,
    }
  },
  props: ['titulo'],

}

</script>