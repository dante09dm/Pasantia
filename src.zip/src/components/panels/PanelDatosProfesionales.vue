<template>
    <VCard class="border">
        <FormDatosProfesionales />
    </VCard>
</template>

<script>
import FormFamiliares from '../forms/FormFamiliares.vue'

export default {
    components: {
        FormFamiliares
    },
    data: () => ({

    })

}
</script>