<template>
    <div>
        <v-container>
            <v-row>
                <v-col cols="12" md="6">
                    <UserCard />
                </v-col>
                <v-col cols="12" md="6">
                    <ListCard />
                </v-col>
            </v-row>
        </v-container>
    </div> 

</template>

<script>
import UserCard from '@/components/dashboardComponets/UserCard.vue'
import ListCard from '@/components/dashboardComponets/ListCard.vue'


export default {
    name: "Dashboard",
    components: {
        UserCard,
        ListCard,
    },

    data() {
        return {

        }
    },

    computed: {

    },
    methods: {
    }

}

</script>