<template>
    <div>

    </div>
</template>

<script>
export default {
    name: 'EditEmail',

    data() {
        return {

        }
    }
}

</script>