<template>
    <v-row>
        <v-col>
            <v-card class="mt-10"> 
                <v-card-title>Pre Afiliacion

                </v-card-title>
            </v-card>
        </v-col>
    </v-row>

                

</template>


<script>



export default {
    components: {
        
    },

    data() {
        return {

        }
    },
    mounted() {

    },
    created() {

    }


}

</script>